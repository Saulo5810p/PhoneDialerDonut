/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.phone;

import android.app.Activity;
import android.content.Intent;
import com.android.phone.compat.TelephonyIntentsCompat;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.PhoneNumberUtils;
import android.util.Log;

/**
 * OutgoingCallBroadcaster receives CALL Intents and sends out broadcast
 * Intents that allow other applications to monitor, redirect, or prevent
 * the outgoing call.  If not aborted, the broadcasts will reach
 * {@link OutgoingCallReceiver}, and be passed on to {@link InCallScreen}.
 *
 * Emergency calls and calls to voicemail when no number is present are
 * exempt from being broadcast.
 *
 * NOTA: este arquivo não usava nenhuma API interna de telefonia de verdade
 * (o import de com.android.internal.telephony.Phone estava sobrando, sem
 * uso no corpo da classe) -- só precisou trocar android.util.Config (classe
 * removida do SDK moderno) por uma constante local, igual ao padrão DBG
 * usado no resto do projeto. Continua funcional como estava.
 */
public class OutgoingCallBroadcaster extends Activity {

    private static final String TAG = "OutgoingCallBroadcaster";
    private static final boolean LOGV = false;

    public static final String EXTRA_ALREADY_CALLED = "android.phone.extra.ALREADY_CALLED";
    public static final String EXTRA_ORIGINAL_URI = "android.phone.extra.ORIGINAL_URI";

    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        Intent intent = getIntent();
        if (LOGV) Log.v(TAG, "onResume: Got intent " + intent + ".");

        String action = intent.getAction();
        String number = PhoneNumberUtils.getNumberFromIntent(intent, this);
        if (number != null) {
            number = PhoneNumberUtils.convertKeypadLettersToDigits(number);
            number = PhoneNumberUtils.stripSeparators(number);
        }
        final boolean emergencyNumber =
                (number != null) && PhoneNumberUtils.isEmergencyNumber(number);

        if (getClass().getName().equals(intent.getComponent().getClassName())) {
            // If we were launched directly from the OutgoingCallBroadcaster,
            // not one of its more privileged aliases, then make sure that
            // only the non-privileged actions are allowed.
            if (!Intent.ACTION_CALL.equals(intent.getAction())) {
                Log.w(TAG, "Attempt to deliver non-CALL action; forcing to CALL");
                intent.setAction(Intent.ACTION_CALL);
            }
        }
        
        /* Change CALL_PRIVILEGED into CALL or CALL_EMERGENCY as needed. */
        if (TelephonyIntentsCompat.ACTION_CALL_PRIVILEGED.equals(action)) {
            action = emergencyNumber
                    ? TelephonyIntentsCompat.ACTION_CALL_EMERGENCY
                    : Intent.ACTION_CALL;
            intent.setAction(action);
        }

        if (Intent.ACTION_CALL.equals(action)) {
            if (emergencyNumber) {
                Log.w(TAG, "Cannot call emergency number " + number
                        + " with CALL Intent " + intent + ".");
                finish();
                return;
            }
        } else if (TelephonyIntentsCompat.ACTION_CALL_EMERGENCY.equals(action)) {
            if (!emergencyNumber) {
                Log.w(TAG, "Cannot call non-emergency number " + number
                        + " with EMERGENCY_CALL Intent " + intent + ".");
                finish();
                return;
            }
        } else {
            Log.e(TAG, "Unhandled Intent " + intent + ".");
            finish();
            return;
        }

        // Make sure the screen is turned on.  This is probably the right
        // thing to do, and more importantly it works around an issue in the
        // activity manager where we will not launch activities consistently
        // when the screen is off (since it is trying to keep them paused
        // and has...  issues).
        //
        // Also, this ensures the device stays awake while doing the following
        // broadcast; technically we should be holding a wake lock here
        // as well.
        PhoneApp.getInstance().wakeUpScreen();

        // Entrega a chamada pro Telecom do sistema. Ele que cuida do
        // NEW_OUTGOING_CALL (protegido, só o sistema pode mandar) e do
        // disque de verdade; a InCallScreen é aberta depois, quando o
        // DonutInCallService recebe onCallAdded pra essa chamada.
        TelecomManager telecomManager =
                (TelecomManager) getSystemService(TELECOM_SERVICE);
        if (telecomManager != null) {
            telecomManager.placeCall(intent.getData(), intent.getExtras());
        } else {
            Log.e(TAG, "TelecomManager indisponível, não foi possível originar a chamada.");
        }

        finish();
    }

}
